package com.tweetApp.FSE.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tweetApp.FSE.DTO.TweetRequestDTO;
import com.tweetApp.FSE.Model.Reply;
import com.tweetApp.FSE.Model.Tweet;
import com.tweetApp.FSE.Service.TweetService;

import io.swagger.annotations.Api;

@Api(tags = { "TwitterManagement" })
@RestController
@RequestMapping(value = "/api/v1.0/tweets")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class TweetController {

	@Autowired
	TweetService tweetService;

	
	@PostMapping("/posttweet")
	public String postTweet(@RequestBody TweetRequestDTO tweetRequest) {
		String message = tweetService.postTweet(tweetRequest);
		return message;
	}

	@GetMapping("/gettweets")
	public List<Tweet> getAllTweets() {

		return tweetService.getAllTweets();
	}
	
	@PostMapping("/reply")
	public boolean postReply(@RequestBody Reply reply) {
		return tweetService.postReply(reply);
	}

	@DeleteMapping("/delete")
	public boolean deleteTweet(@RequestParam("tweetId") int tweetId) {
		return tweetService.deleteTweet(tweetId);
	}
}
