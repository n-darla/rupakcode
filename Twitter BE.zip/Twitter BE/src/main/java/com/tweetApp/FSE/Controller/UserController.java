package com.tweetApp.FSE.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tweetApp.FSE.DTO.ForgotPasswordRequest;
import com.tweetApp.FSE.DTO.LoginRequestDTO;
import com.tweetApp.FSE.DTO.ResetPasswordRequestDTO;
import com.tweetApp.FSE.Model.Register;
import com.tweetApp.FSE.Model.Tweet;
import com.tweetApp.FSE.Service.UserService;

import io.swagger.annotations.Api;

@Api(tags = { "TwittersUserManagement" })
@RestController
@RequestMapping(value = "/api/v1.0/tweets")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UserController {

	@Autowired
	UserService userService;

	@PostMapping("/register")
	public boolean register(@RequestBody Register register) {
		register = userService.register(register);
		if (register == null) {
			return false;
		} else {
			return true;
		}
	}

	@PostMapping("/login")
	public boolean login(@RequestBody LoginRequestDTO loginRequest) {
		return userService.login(loginRequest);
	}

	@PutMapping("/reset")
	public boolean resetpassword(@RequestBody ResetPasswordRequestDTO request) {
		return userService.resetpassword(request);
	}
	
	@PutMapping("/forgetPassword")
	public boolean forgotpassword(@RequestBody ForgotPasswordRequest  resetRequest) {
		return userService.forgotPassword(resetRequest);
	}

	@GetMapping("/getallUsers")
	public List<Register> getAllUsers() {
		return userService.getAllUsers();
	}

	@GetMapping("/UsersTweet")
	public List<Tweet> getUsersTweet(@RequestParam("email") String email) {
		return userService.getUsersTweet(email);
	}
}
