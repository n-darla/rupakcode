package com.tweetApp.FSE.Repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.tweetApp.FSE.Model.Reply;

@Repository
public class ReplyRepository {

	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	public void save(Reply reply) {
		dynamoDBMapper.save(reply);
	}

	public List<Reply> findByTweetId(String tweetId) {
		HashMap<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
		eav.put(tweetId, new AttributeValue().withS(tweetId));
		DynamoDBScanExpression scanExpression = new DynamoDBScanExpression()
				.withFilterExpression("begins_with(tweetId,:v1)").withExpressionAttributeValues(eav);
		List<Reply> result = dynamoDBMapper.scan(Reply.class, scanExpression);

		return result;
	}
	
	public List<Reply> findAll() {
		DynamoDBScanExpression scanner = new DynamoDBScanExpression();
		List<Reply> result = dynamoDBMapper.scan(Reply.class, scanner);
		return result;
	}
	public void deleteById(int id) {
		Reply reply = dynamoDBMapper.load(Reply.class, id);
		dynamoDBMapper.delete(reply);
	}

}
