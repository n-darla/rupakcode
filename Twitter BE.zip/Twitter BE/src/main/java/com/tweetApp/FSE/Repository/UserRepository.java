package com.tweetApp.FSE.Repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.tweetApp.FSE.Model.Register;
import com.tweetApp.FSE.Model.Tweet;

@Repository
public class UserRepository {

	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	public void save(Register register) {
		dynamoDBMapper.save(register);
	}

	public void deleteById(int tweetId) {
		Tweet result = dynamoDBMapper.load(Tweet.class, tweetId);
		dynamoDBMapper.delete(result);
	}

	public Register findByEmail(String email) {

		Register result = dynamoDBMapper.load(Register.class, email);
		return result;
	}

	public Register findById(int id) {
		return dynamoDBMapper.load(Register.class, id);
	}

}
