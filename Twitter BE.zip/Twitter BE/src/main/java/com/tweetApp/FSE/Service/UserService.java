package com.tweetApp.FSE.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetApp.FSE.DTO.ForgotPasswordRequest;
import com.tweetApp.FSE.DTO.LoginRequestDTO;
import com.tweetApp.FSE.DTO.ResetPasswordRequestDTO;
import com.tweetApp.FSE.Model.Register;
import com.tweetApp.FSE.Model.Tweet;
import com.tweetApp.FSE.Repository.RegisterRepository;
import com.tweetApp.FSE.Repository.TweetRepository;
import com.tweetApp.FSE.Repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepo;

	@Autowired
	RegisterRepository registerRepo;
	
	@Autowired TweetRepository tweetRepo;

	public Register register(Register register) {
		List<Register> regList = registerRepo.findAll();
		for(int index = 0; index < regList.size();index ++) {
			if(regList.get(index).getEmail().equals(register.getEmail())) {
			register = null;
			return register;
			}
		}
		int count = regList.size() + 1;
		register.setId(count);
		userRepo.save(register);
		return register;
	}

	public boolean login(LoginRequestDTO loginRequestDTO) {
		List<Register> list = registerRepo.findAll();
		for(int index = 0; index < list.size();index ++) {
			if(list.get(index).getEmail().equals(loginRequestDTO.getEmail()) && list.get(index).getPassword().equals(loginRequestDTO.getPassword())) {
				return true;
			}
		}
		return false;
	}

	public boolean resetpassword(ResetPasswordRequestDTO resetRequest) {
		List<Register> list = registerRepo.findAll();
		for(int index =0; index < list.size(); index ++) {
			if (list.get(index).getEmail().equals(resetRequest.getEmailId()) && list.get(index).getPassword().equals(resetRequest.getOldpassword())) {
				Register register = list.get(index);
				register.setPassword(resetRequest.getNewpassword());
				registerRepo.save(register);
				return true;
			}
		}
			return false;
	}

	public List<Register> getAllUsers() {
		List<Register> list = new ArrayList<>();
		list = registerRepo.findAll();
		return list;
	}

	public List<Tweet> getUsersTweet(String email) {
		List<Tweet> list = tweetRepo.findAll();
		List<Tweet> tweetList = new ArrayList<>();
		for(int index = 0; index < list.size(); index ++) {
			if(list.get(index).getEmail().equals(email)) {
				tweetList.add(list.get(index));
			}
		}
		return tweetList;
	}

	public boolean forgotPassword(ForgotPasswordRequest request) {
		List<Register> list = registerRepo.findAll();
		for(int index =0; index < list.size(); index ++) {
			if (list.get(index).getEmail().equals(request.getEmail())) {
				Register register = list.get(index);
				register.setPassword(request.getPassword());
				registerRepo.save(register);
				return true;
			}
		}
			return false;
	}

}
